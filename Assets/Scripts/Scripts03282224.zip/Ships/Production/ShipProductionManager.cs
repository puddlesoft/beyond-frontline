using System.Collections.Generic;
using UnityEngine;

public class ShipProductionManager : MonoBehaviour
{
    private Dictionary<Shipyard.ShipyardType, Queue<Shipyard>> shipyardQueues = new();
    private Queue<BuildRequest> buildQueue = new();
    private const int maxQueueSize = 50;

    public void RegisterShipyard(Shipyard.ShipyardType type, Shipyard yard)
    {
        if (!shipyardQueues.ContainsKey(type))
        {
            shipyardQueues[type] = new Queue<Shipyard>();
        }

        shipyardQueues[type].Enqueue(yard);
    }

    public void EnqueueBuild(Shipyard.ShipyardType type, Shipyard origin)
    {
        if (buildQueue.Count >= maxQueueSize)
            return;

        buildQueue.Enqueue(new BuildRequest(type, origin));
    }

    public void Tick(PlayerResourceSystem playerSystem)
    {
        ProcessBuildQueue(playerSystem, true);
    }

    public void Tick(EnemyResourceSystem enemySystem)
    {
        ProcessBuildQueue(enemySystem, false);
    }

    void ProcessBuildQueue(object system, bool isPlayer)
    {
        int buildsThisFrame = 0;

        int queueSize = buildQueue.Count;
        for (int i = 0; i < queueSize && buildsThisFrame < 3; i++) // Limit builds per frame
        {
            BuildRequest request = buildQueue.Dequeue();
            Shipyard yard = request.origin;

            if (yard == null) continue;

            bool canAfford = isPlayer
                ? yard.CanPlayerAfford((PlayerResourceSystem)system)
                : yard.CanEnemyAfford((EnemyResourceSystem)system);

            if (canAfford)
            {
                yard.SpawnShip(isPlayer);
                buildsThisFrame++;
            }
            else
            {
                // Re-enqueue for later
                buildQueue.Enqueue(request);
            }
        }
    }

    private class BuildRequest
    {
        public Shipyard.ShipyardType type;
        public Shipyard origin;

        public BuildRequest(Shipyard.ShipyardType type, Shipyard origin)
        {
            this.type = type;
            this.origin = origin;
        }
    }
}
